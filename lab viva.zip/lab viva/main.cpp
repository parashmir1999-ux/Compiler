#include <iostream>
#include <fstream>
#include <cstring>
using namespace std;

int main()
{
    ifstream file("parash.txt");
    string word;
    char ch;

    while (file.get(ch))
    {

        if (ch == ' ' || ch == '\n' || ch == '\t')
            continue;

        if ((ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z'))
        {
            word = ch;

            while (file.get(ch) &&
                  ((ch >= 'a' && ch <= 'z') ||
                   (ch >= 'A' && ch <= 'Z') ||
                   (ch >= '0' && ch <= '9')))
            {
                word += ch;
            }

            file.unget();

            if (word == "int" || word == "return" || word == "cout" || word == "main")
                cout << word << " : Keyword" << endl;
            else
                cout << word << " : Identifier" << endl;
        }


        else if (ch >= '0' && ch <= '9')
        {
            word = ch;

            while (file.get(ch) && (ch >= '0' && ch <= '9'))
            {
                word += ch;
            }

            file.unget();
            cout << word << " : Number" << endl;
        }

        else if (ch == '"')
        {
            word = ch;

            while (file.get(ch) && ch != '"')
            {
                word += ch;
            }

            word += '"';
            cout << word << " : String" << endl;
        }


        else if (ch == '=' || ch == '>')
        {
            cout << ch << " : Operator" << endl;
        }

        else if (ch == '(' || ch == ')')
        {
            cout << ch << " : Parenthesis" << endl;
        }

        else if (ch == '{' || ch == '}')
        {
            cout << ch << " : Brace" << endl;
        }


        else if (ch == ';')
        {
            cout << ch << " : Semicolon" << endl;
        }
    }

    file.close();
    return 0;
}
